/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

int
main ()
{
  float peso;
  float costobase;
  float costocolore;
  float costolavorazione;
  float costofinale;
  float costoalgrammo;
  char colore;
  char lavorazione;

  cout << "inserire il peso dell'articolo" << endl;
  cin >> peso;
  cout << "inserire il costo al grammo" << endl;
  cit >> costoalgrammo;
  costobase = costoalgrammo * peso;
  cout << "inserire l'iniziale del colore dell'oro";
  cin >> colore;
  if (colore == r)
  {
      costocolore = (costobase*8)/100;
  }
  if (colore == g)
  {
      
  }
  if (colore == b)
  {
      
  }
  
}
